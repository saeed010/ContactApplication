package com.example.addcontact;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class Contact extends AppCompatActivity {

    EditText firstName, lstName, inputNumber;
    Button add, cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // for adding the contact
        firstName = (EditText) findViewById(R.id.Edt_InputFirstName);
        lstName = (EditText) findViewById(R.id.Edt_InputLstName);
        inputNumber = (EditText) findViewById(R.id.Edt_InputNumber);
        add = (Button) findViewById(R.id.Btn_save);
        cancel = (Button) findViewById(R.id.Btn_cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Contact.this);
                builder.setMessage("App will be closed are you sure to exit ? ");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Contact.this.finish();
                    }
                }).setNegativeButton("Dennied", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
            }
        });
    }
    public void Add_Contact(View view) {//Create Intent Contact_add
        Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
        intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
        intent.putExtra(ContactsContract.Intents.Insert.PHONE, inputNumber.getText())
                .putExtra(ContactsContract.Intents.Insert.PHONE_TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_WORK)
                .putExtra(ContactsContract.Intents.Insert.NAME, firstName.getText()+ " " + lstName.getText().toString());
        startActivity(intent);
        //initialize
        checkedData();
    }
    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }
    //validation check
    void checkedData() {
        if (isEmpty(firstName)) {
            Toast.makeText(this, "numbers are required to save contacts", Toast.LENGTH_LONG).show();
        } else if (isEmpty(lstName)) {
            lstName.setError("last name to procceeed");
        } else if (isEmpty(inputNumber)) {
            inputNumber.setError("not valid number re enter again");
        } else {
            Toast.makeText(this, "Saved successfully", Toast.LENGTH_LONG).show();
        }
    }
}